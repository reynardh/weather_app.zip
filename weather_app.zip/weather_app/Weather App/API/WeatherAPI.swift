//
//  WeatherAPI.swift
//  Weather App
//
//  Created by ReynardH on 08/09/21.
//

import Foundation
import Moya
import Alamofire
import SVProgressHUD
import UIKit

//Define the request body and header and request type
extension WeatherAPI : TargetType{
    
    // Define Header Over here
    var headers: [String: String]? {
        
        let headerParam = [
            "Content-Type": "application/json",
            "Accept": "application/json",
        ]
        
        return headerParam
    }
    
    // Base URL of the api we can define based on request here used comman
    var baseURL: URL {
        
        return URL(string: Constant.BaseURL)!
    }
    
    // Remain path of the api call
    var path: String {
        switch self {
        case .Weather(.current):
            return "weather"
        }
    }
    
    // Define method of the request
    var method: Moya.Method {
        switch self {
        case .Weather(.current):
            return .get
        }
    }
    
    // Define parameters of the api
    var parameters: [String: Any]? {
        switch self {
        
        case .Weather(.current(let cityName, let cityId, let lati, let long)):
            
            var param : [String : Any] = ["appid" : Constant.AppId]
            
            if let cityName = cityName, cityName != ""{
                
                param["q"] = cityName
            }
            
            if let cityId = cityId{
                param["id"] = cityId
            }
            
            if let lati = lati ,
               let long = long{
                
                param["lat"] = lati
                param["lon"] = long
            }
            
            param["units"] = "metric"
            return param
        }
    }
    
    var sampleData: Data {
        return "".utf8Encoded
    }
    
    // Define parameterEncoding weather the parameters are sent in body or in query
    var parameterEncoding: ParameterEncoding {
        
        switch self {
        case .Weather(.current):
            
            return URLEncoding.queryString
        }
        
    }
    
    // Define request type based on above things
    var task: Task{
        if parameters != nil {
            return .requestParameters(parameters: parameters!, encoding: parameterEncoding)
        } else {
            return .requestPlain
        }
    }
    
    
}
