//
//  WeatherAPIEnum.swift
//  Weather App
//
//  Created by ReynardH on 08/09/21.
//

import Foundation
import UIKit

//All API cAll are Define over there
enum WeatherAPI {
 
    enum WeatherEndPoint{
        case current(cityName : String?, cityId: Int?, lati: Double?, long: Double?)
    }
    
    case Weather(WeatherEndPoint)
    
}
