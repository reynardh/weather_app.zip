//
//  Config.swift
//  Weather App
//
//  Created by ReynardH on 08/10/21.
//

import Foundation

//Define Base url and image base url
class Constant {
    static let BaseURL = "https://api.openweathermap.org/data/2.5/"
    static let BaseImageURL = "http://openweathermap.org/img/w/"
    static let AppId = "85e52a18aa51982aeb089f188a7a3e6c"

    static let temperatureUnit = "°C"
    static let humidityUnit = "%"
    static let windUnit = "m/s"
    static let dataSeperator = "-"
}
