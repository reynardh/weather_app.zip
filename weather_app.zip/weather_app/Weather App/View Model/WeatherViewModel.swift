//
//  WeatherViewModel.swift
//  Weather App
//
//  Created by ReynardH on 08/09/21.
//

import Foundation
import UIKit
import SVProgressHUD

class WetherViewModel{
    
    func getCurrentWeather(cityName : String?, id: Int?, lati: Double?, long: Double?,onSuccess: @escaping (WeatherRootClass) -> Void, onError: @escaping (String?) -> Void) {
        SVProgressHUD.show(withStatus: "loading".localized())
        
        Network.request(.Weather(.current(cityName: cityName, cityId: id, lati: lati, long: long)), decodeType: WeatherRootClass.self, errorDecodeType: ErrorRootClass.self, success: { (statusCode, result)  in
            
            SVProgressHUD.dismiss()
            if result.cod == HTTPStatusCode.ok.rawValue{
                
                onSuccess(result)
            } else {
                
                onError("failed_to_load_data".localized())
            }
        }, error: { (statusCode, errorResult, errorMessage) in
            
            SVProgressHUD.dismiss()
            onError(errorResult?.message)
            
        }, failure: { error in
            
            SVProgressHUD.dismiss()
            onError(error.localizedDescription)
            
        }, completion: {
            
            SVProgressHUD.dismiss()
            
        })
    }
    
}
