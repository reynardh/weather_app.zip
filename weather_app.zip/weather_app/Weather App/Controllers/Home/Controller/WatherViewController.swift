//
//  ViewController.swift
//  Weather App
//
//  Created by ReynardH on 08/09/21.
//

import UIKit
import SDWebImage
import CoreLocation

class WatherViewController: UIViewController {
    
    // View Outlets
    @IBOutlet weak var lblTemp : UILabel!
    @IBOutlet weak var lblMaxMin : UILabel!
    @IBOutlet weak var lblMsg : UILabel!
    @IBOutlet weak var lblHumadity : UILabel!
    @IBOutlet weak var lblWindSpeed : UILabel!
    @IBOutlet weak var lblWindGust : UILabel!
    @IBOutlet weak var lblWindDirection : UILabel!
    @IBOutlet weak var lblHumadityValue : UILabel!
    @IBOutlet weak var lblWindSpeedValue : UILabel!
    @IBOutlet weak var lblWindGustValue : UILabel!
    @IBOutlet weak var lblWindDirectionValue : UILabel!
    @IBOutlet weak var lblLocation : UILabel!
    @IBOutlet weak var txtLocation : UITextField!
    @IBOutlet weak var imgWeather : UIImageView!
    
    // View Model to Feath the data
    private let viewModel = WetherViewModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Populate Default Location and fetch Data
        txtLocation.text = "Long Island"
        performClickActionAndGetData()
        
    }
    
    
    // On Get Weather Button Click get the data
    @IBAction func btnGetWeather( _ sender : UIButton){
        
        performClickActionAndGetData()
        
    }
    
    private func performClickActionAndGetData(){
        
        if let cityNameString = txtLocation.text, cityNameString != ""{
            
            //Close Keyboard
            self.view.endEditing(true)
            
            // Get latitude and longitude of added string if not present then send the name string to get weather data
            getLocationBasedOnCityString(cityName: cityNameString) { isSuccess, location in
                
                if isSuccess{
                    
                    self.getCurrentWeather(lati: location!.latitude, long: location!.longitude)
                    
                } else {
                    
                    self.getCurrentWeather(cityNameString: cityNameString, lati: nil, long: nil)
                }
            }
            
        } else {
            
            ShowAlert(message: "enter_city_name".localized(), theme: .error)
        }
    }
    
    // Comman function to get weather data
    func getCurrentWeather(cityNameString : String? = nil, lati: Double? = nil,long: Double? = nil){
        
        // Check weather the input is number then considered as a city id else considered as a name
        var cityId : Int? = nil
        var cityName : String? = nil
        if cityNameString != nil ,cityNameString != ""{
            
            cityName = cityNameString
            if let id = Int(cityNameString!){
                cityId = id
            }
        }
        
        // Making api Call and get the data, if success then populate in view else show error message
        viewModel.getCurrentWeather(cityName: cityName,id: cityId,lati: lati,long: long) { (weather) in
            
            
            // Show all data on view
            if let main = weather.main{
                if let max = main.tempMax,
                   let min = main.tempMin,
                   let humedity = main.humidity,
                   let temp = main.temp{
                    
                    self.lblMaxMin.text = "\(max)\(Constant.temperatureUnit) / \(min)\(Constant.temperatureUnit)"
                    self.lblHumadityValue.text = "\(humedity)\(Constant.humidityUnit)"
                    self.lblTemp.text = "\(temp)\(Constant.temperatureUnit)"
                    
                }
            }
            
            
            self.lblMsg.text = weather.weather?.first?.descriptionField?.capitalized ?? Constant.dataSeperator
            self.lblWindSpeedValue.text = ((weather.wind?.speed) != nil) ? "\(weather.wind!.speed!) \(Constant.windUnit)" : Constant.dataSeperator
            self.lblWindDirectionValue.text = ((weather.wind?.deg) != nil) ? "\(weather.wind!.deg!) \(Constant.windUnit)" : Constant.dataSeperator
            self.lblWindGustValue.text = ((weather.wind?.gust) != nil) ? "\(weather.wind!.gust!) \(Constant.windUnit)" : Constant.dataSeperator
            
            
            if let urlString = weather.weather?.first?.getImageURL() , urlString != ""{
            
                let url = URL(string: urlString)
                self.imgWeather.sd_setImage(with: url)
                
            }
            
        } onError: { (errorResult) in
            
            if let errResult = errorResult{
                
                ShowAlert(message: errResult, theme: .error)
            }
        }
    }
}
