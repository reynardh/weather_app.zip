//
//  GlobleFunction.swift
//  Weather App
//
//  Created by ReynardH on 08/10/21.
//

import Foundation
import SwiftMessages
import CoreLocation

func ShowAlert(message : String, theme: Theme, tapHandler: (() -> Void)? = nil) {
    
    let view = MessageView.viewFromNib(layout: .cardView)
    view.button?.isHidden = true
    view.configureTheme(theme)
    view.configureTheme(backgroundColor: UIColor.lightGray , foregroundColor: UIColor.black, iconImage: nil, iconText: "")
    view.configureContent(title: "app_name".localized(), body: message, iconText: "")
    view.tapHandler = { _ in
        
        SwiftMessages.hide()
        
        if let block = tapHandler{
            
            block()
        }
    }
    var config = SwiftMessages.defaultConfig
    config.interactiveHide = true
    config.becomeKeyWindow = true
    config.duration = .seconds(seconds: 4)
    config.presentationContext = .window(windowLevel: UIWindow.Level.normal)
    SwiftMessages.show(config: config, view: view)
    
}

func getLocationBasedOnCityString(cityName: String, onComplition : (( _ isSuccess: Bool , _ location : CLLocationCoordinate2D?) -> Void)?){
    
    let geoCoder = CLGeocoder()
    geoCoder.geocodeAddressString(cityName) { (placemarks, error) in
        if
            let placemarks = placemarks,
            let location = placemarks.first?.location{
            
            if let block = onComplition{
                
                block(true, location.coordinate)
            }
            
        } else {
            if let block = onComplition{
                block(false, nil)
            }
        }
    }
}
