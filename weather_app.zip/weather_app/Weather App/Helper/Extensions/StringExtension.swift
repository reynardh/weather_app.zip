//
//  StringExtension.swift
//  Weather App
//
//  Created by Apple on 12/08/21.
//

import Foundation
extension String{
    
    var utf8Encoded: Data { return data(using: .utf8)! }
    
    func localized() -> String {
        return NSLocalizedString(self, comment: "")
    }
}
